"use server"

import { auth } from "@/lib/auth"
import { db } from "@/lib/db"
import { titles, episodes, episodeSources } from "@/lib/db/schema"
import { eq } from "drizzle-orm"
import { headers } from "next/headers"
import { revalidatePath } from "next/cache"

async function requireUser() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) throw new Error("Unauthorized")
  return session.user.id
}

function slugify(input: string) {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
}

// ---------- Titles ----------
export async function createTitle(formData: FormData) {
  await requireUser()
  const title = String(formData.get("title") ?? "").trim()
  if (!title) return { ok: false, error: "Title is required" }

  const baseSlug = slugify(title)
  const existing = await db.select().from(titles).where(eq(titles.slug, baseSlug)).limit(1)
  const slug = existing.length > 0 ? `${baseSlug}-${Date.now().toString().slice(-4)}` : baseSlug

  const yearRaw = String(formData.get("releaseYear") ?? "").trim()
  const year = yearRaw ? Number.parseInt(yearRaw, 10) : null

  await db.insert(titles).values({
    kind: String(formData.get("kind") ?? "anime"),
    title,
    slug,
    description: String(formData.get("description") ?? ""),
    posterUrl: String(formData.get("posterUrl") ?? ""),
    bannerUrl: String(formData.get("bannerUrl") ?? ""),
    genres: String(formData.get("genres") ?? ""),
    releaseYear: Number.isNaN(year as number) ? null : year,
    rating: String(formData.get("rating") ?? ""),
    featured: formData.get("featured") === "on",
  })

  revalidatePath("/admin")
  revalidatePath("/")
  return { ok: true }
}

export async function deleteTitle(titleId: number) {
  await requireUser()
  const eps = await db.select().from(episodes).where(eq(episodes.titleId, titleId))
  for (const ep of eps) {
    await db.delete(episodeSources).where(eq(episodeSources.episodeId, ep.id))
  }
  await db.delete(episodes).where(eq(episodes.titleId, titleId))
  await db.delete(titles).where(eq(titles.id, titleId))
  revalidatePath("/admin")
  revalidatePath("/")
  return { ok: true }
}

// ---------- Episodes ----------
export async function createEpisode(formData: FormData) {
  await requireUser()
  const titleId = Number.parseInt(String(formData.get("titleId") ?? ""), 10)
  if (Number.isNaN(titleId)) return { ok: false, error: "Invalid title" }

  await db.insert(episodes).values({
    titleId,
    season: Number.parseInt(String(formData.get("season") ?? "1"), 10) || 1,
    episodeNumber: Number.parseInt(String(formData.get("episodeNumber") ?? "1"), 10) || 1,
    name: String(formData.get("name") ?? ""),
    description: String(formData.get("description") ?? ""),
    thumbnailUrl: String(formData.get("thumbnailUrl") ?? ""),
    duration: String(formData.get("duration") ?? ""),
  })

  revalidatePath("/admin")
  return { ok: true }
}

export async function deleteEpisode(episodeId: number) {
  await requireUser()
  await db.delete(episodeSources).where(eq(episodeSources.episodeId, episodeId))
  await db.delete(episodes).where(eq(episodes.id, episodeId))
  revalidatePath("/admin")
  return { ok: true }
}

// ---------- Sources (quality options) ----------
export async function createSource(formData: FormData) {
  await requireUser()
  const episodeId = Number.parseInt(String(formData.get("episodeId") ?? ""), 10)
  if (Number.isNaN(episodeId)) return { ok: false, error: "Invalid episode" }

  await db.insert(episodeSources).values({
    episodeId,
    quality: String(formData.get("quality") ?? "720p"),
    url: String(formData.get("url") ?? ""),
    downloadUrl: String(formData.get("downloadUrl") ?? ""),
  })

  revalidatePath("/admin")
  return { ok: true }
}

export async function deleteSource(sourceId: number) {
  await requireUser()
  await db.delete(episodeSources).where(eq(episodeSources.id, sourceId))
  revalidatePath("/admin")
  return { ok: true }
}
