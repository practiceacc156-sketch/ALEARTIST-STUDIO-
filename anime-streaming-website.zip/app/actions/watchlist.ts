"use server"

import { auth } from "@/lib/auth"
import { db } from "@/lib/db"
import { watchlist } from "@/lib/db/schema"
import { and, eq } from "drizzle-orm"
import { headers } from "next/headers"
import { revalidatePath } from "next/cache"

async function getOptionalUserId() {
  const session = await auth.api.getSession({ headers: await headers() })
  return session?.user?.id ?? null
}

export async function isInWatchlist(titleId: number) {
  const userId = await getOptionalUserId()
  if (!userId) return false
  const rows = await db
    .select()
    .from(watchlist)
    .where(and(eq(watchlist.userId, userId), eq(watchlist.titleId, titleId)))
    .limit(1)
  return rows.length > 0
}

export async function toggleWatchlist(titleId: number) {
  const userId = await getOptionalUserId()
  if (!userId) return { ok: false, reason: "unauthenticated" as const }

  const existing = await db
    .select()
    .from(watchlist)
    .where(and(eq(watchlist.userId, userId), eq(watchlist.titleId, titleId)))
    .limit(1)

  let added: boolean
  if (existing.length > 0) {
    await db.delete(watchlist).where(and(eq(watchlist.userId, userId), eq(watchlist.titleId, titleId)))
    added = false
  } else {
    await db.insert(watchlist).values({ userId, titleId })
    added = true
  }

  revalidatePath("/watchlist")
  return { ok: true as const, added }
}
