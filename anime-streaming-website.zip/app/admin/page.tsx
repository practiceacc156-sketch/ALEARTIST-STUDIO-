import { redirect } from "next/navigation"
import { headers } from "next/headers"
import { auth } from "@/lib/auth"
import { Navbar } from "@/components/navbar"
import { AdminManager } from "@/components/admin/admin-manager"
import { getAdminData } from "@/lib/queries"

export default async function AdminPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect("/sign-in?redirect=/admin")

  const data = await getAdminData()

  return (
    <div className="min-h-svh bg-background">
      <Navbar />
      <main className="mx-auto max-w-5xl px-4 pt-24 pb-12 md:px-8">
        <div className="mb-6">
          <h1 className="font-heading text-3xl tracking-wide text-foreground md:text-4xl">Studio Admin</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Manage titles, episodes, and quality sources for ALEARTIST STUDIO INDIA.
          </p>
        </div>
        <AdminManager titles={data} />
      </main>
    </div>
  )
}
