import { notFound } from "next/navigation"
import { Navbar } from "@/components/navbar"
import { SiteFooter } from "@/components/site-footer"
import { ContentGrid } from "@/components/content-grid"
import { getTitlesByKind, KIND_LABELS, KINDS, type Kind } from "@/lib/queries"

export function generateStaticParams() {
  return KINDS.map((kind) => ({ kind }))
}

export default async function BrowsePage({ params }: { params: Promise<{ kind: string }> }) {
  const { kind } = await params
  if (!KINDS.includes(kind as Kind)) notFound()
  const k = kind as Kind
  const titles = await getTitlesByKind(k)

  return (
    <div className="min-h-svh bg-background">
      <Navbar />
      <main className="pt-24 pb-8">
        <div className="mb-6 px-4 md:px-8">
          <h1 className="font-heading text-3xl tracking-wide text-foreground md:text-4xl">
            {KIND_LABELS[k]}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Browse all {KIND_LABELS[k].toLowerCase()} on ALEARTIST STUDIO INDIA
          </p>
        </div>
        <ContentGrid titles={titles} />
      </main>
      <SiteFooter />
    </div>
  )
}
