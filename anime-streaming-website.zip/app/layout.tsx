import { Analytics } from "@vercel/analytics/next"
import type { Metadata } from "next"
import { Inter, Bebas_Neue } from "next/font/google"
import "./globals.css"

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
})

const bebas = Bebas_Neue({
  variable: "--font-bebas",
  weight: "400",
  subsets: ["latin"],
})

export const metadata: Metadata = {
  title: "ALEARTIST STUDIO INDIA — Watch Anime, Movies, Web Series & K-Dramas Free",
  description:
    "ALEARTIST STUDIO INDIA — Stream and download fan-dubbed anime, movies, web series, and K-dramas for free in HD. Multiple quality options on every episode.",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`dark ${inter.variable} ${bebas.variable}`}>
      <body className="font-sans antialiased bg-background text-foreground">
        {children}
        {process.env.NODE_ENV === "production" && <Analytics />}
      </body>
    </html>
  )
}
