import { Navbar } from "@/components/navbar"
import { Hero } from "@/components/hero"
import { ContentRow } from "@/components/content-row"
import { SiteFooter } from "@/components/site-footer"
import { getFeaturedTitle, getTitlesByKind, getAllTitles, KIND_LABELS } from "@/lib/queries"

export default async function HomePage() {
  const [featured, anime, movies, webseries, kdramas, all] = await Promise.all([
    getFeaturedTitle(),
    getTitlesByKind("anime"),
    getTitlesByKind("movie"),
    getTitlesByKind("webseries"),
    getTitlesByKind("kdrama"),
    getAllTitles(),
  ])

  return (
    <div className="min-h-svh bg-background">
      <Navbar />
      <main>
        {featured && <Hero title={featured} />}

        <div className="relative z-10 -mt-8 pb-8">
          <ContentRow heading="Trending Now" titles={all.slice(0, 12)} />
          <ContentRow heading={KIND_LABELS.anime} titles={anime} viewAllHref="/browse/anime" />
          <ContentRow heading={KIND_LABELS.movie} titles={movies} viewAllHref="/browse/movie" />
          <ContentRow heading={KIND_LABELS.webseries} titles={webseries} viewAllHref="/browse/webseries" />
          <ContentRow heading={KIND_LABELS.kdrama} titles={kdramas} viewAllHref="/browse/kdrama" />
        </div>
      </main>
      <SiteFooter />
    </div>
  )
}
