import { Navbar } from "@/components/navbar"
import { SiteFooter } from "@/components/site-footer"
import { ContentGrid } from "@/components/content-grid"
import { searchTitles } from "@/lib/queries"

export default async function SearchPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q } = await searchParams
  const query = q ?? ""
  const results = query ? await searchTitles(query) : []

  return (
    <div className="min-h-svh bg-background">
      <Navbar />
      <main className="pt-24 pb-8">
        <div className="mb-6 px-4 md:px-8">
          <h1 className="text-2xl font-semibold text-foreground">
            {query ? `Results for "${query}"` : "Search"}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {query ? `${results.length} title(s) found` : "Type a title or genre in the search bar above."}
          </p>
        </div>
        {query && <ContentGrid titles={results} />}
      </main>
      <SiteFooter />
    </div>
  )
}
