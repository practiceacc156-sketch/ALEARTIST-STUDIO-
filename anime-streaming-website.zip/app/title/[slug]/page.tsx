import Link from "next/link"
import { notFound } from "next/navigation"
import { headers } from "next/headers"
import { Play } from "lucide-react"
import { Navbar } from "@/components/navbar"
import { SiteFooter } from "@/components/site-footer"
import { WatchlistButton } from "@/components/watchlist-button"
import { Button } from "@/components/ui/button"
import { auth } from "@/lib/auth"
import { getTitleBySlug, getEpisodesForTitle } from "@/lib/queries"
import { isInWatchlist } from "@/app/actions/watchlist"

export default async function TitlePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const title = await getTitleBySlug(slug)
  if (!title) notFound()

  const [episodes, session] = await Promise.all([
    getEpisodesForTitle(title.id),
    auth.api.getSession({ headers: await headers() }),
  ])
  const inList = await isInWatchlist(title.id)
  const firstEpisode = episodes[0]

  return (
    <div className="min-h-svh bg-background">
      <Navbar />
      <main>
        <section className="relative h-[60vh] min-h-[420px] w-full">
          {(title.bannerUrl || title.posterUrl) && (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={title.bannerUrl || title.posterUrl || "/placeholder.svg"}
              alt={`${title.title} banner`}
              className="absolute inset-0 h-full w-full object-cover"
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/70 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
          <div className="relative z-10 mx-auto flex h-full max-w-7xl flex-col justify-end px-4 pb-10 md:px-8">
            <h1 className="max-w-2xl font-heading text-4xl leading-none tracking-wide text-foreground md:text-5xl text-balance">
              {title.title}
            </h1>
            <div className="mt-3 flex flex-wrap items-center gap-3 text-sm text-foreground/80">
              {title.releaseYear && <span>{title.releaseYear}</span>}
              {title.rating && <span className="rounded border border-border px-1.5 py-0.5 text-xs">{title.rating}</span>}
              {title.genres && <span>{title.genres.split(",").join(" • ")}</span>}
              <span>{episodes.length} episode{episodes.length === 1 ? "" : "s"}</span>
            </div>
            <p className="mt-4 max-w-2xl text-sm leading-relaxed text-foreground/80 md:text-base">
              {title.description}
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              {firstEpisode && (
                <Button asChild size="lg" className="gap-2">
                  <Link href={`/watch/${title.slug}/${firstEpisode.id}`}>
                    <Play className="size-5 fill-current" /> Play Episode 1
                  </Link>
                </Button>
              )}
              <WatchlistButton titleId={title.id} initialInList={inList} isAuthed={!!session?.user} />
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-4 py-8 md:px-8">
          <h2 className="mb-4 text-xl font-semibold text-foreground">Episodes</h2>
          <ul className="flex flex-col gap-3">
            {episodes.map((ep) => (
              <li key={ep.id}>
                <Link
                  href={`/watch/${title.slug}/${ep.id}`}
                  className="group flex items-center gap-4 rounded-lg border border-border bg-card p-3 transition-colors hover:border-primary"
                >
                  <div className="relative aspect-video w-32 shrink-0 overflow-hidden rounded-md bg-secondary sm:w-44">
                    {ep.thumbnailUrl && (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={ep.thumbnailUrl || "/placeholder.svg"} alt="" className="h-full w-full object-cover" />
                    )}
                    <div className="absolute inset-0 flex items-center justify-center bg-black/30 opacity-0 transition-opacity group-hover:opacity-100">
                      <Play className="size-7 fill-white text-white" />
                    </div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-primary">EP {ep.episodeNumber}</span>
                      {ep.duration && <span className="text-xs text-muted-foreground">{ep.duration}</span>}
                    </div>
                    <h3 className="truncate text-sm font-medium text-foreground">{ep.name || `Episode ${ep.episodeNumber}`}</h3>
                    <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{ep.description}</p>
                  </div>
                </Link>
              </li>
            ))}
            {episodes.length === 0 && (
              <p className="text-sm text-muted-foreground">No episodes added yet.</p>
            )}
          </ul>
        </section>
      </main>
      <SiteFooter />
    </div>
  )
}
