import Link from "next/link"
import { notFound } from "next/navigation"
import { Navbar } from "@/components/navbar"
import { VideoPlayer } from "@/components/video-player"
import { getTitleBySlug, getEpisodeById, getSourcesForEpisode, getAdjacentEpisodes } from "@/lib/queries"
import { cn } from "@/lib/utils"

export default async function WatchPage({ params }: { params: Promise<{ slug: string; episodeId: string }> }) {
  const { slug, episodeId } = await params
  const epId = Number.parseInt(episodeId, 10)
  if (Number.isNaN(epId)) notFound()

  const title = await getTitleBySlug(slug)
  if (!title) notFound()

  const episode = await getEpisodeById(epId)
  if (!episode || episode.titleId !== title.id) notFound()

  const [sources, adjacent] = await Promise.all([
    getSourcesForEpisode(epId),
    getAdjacentEpisodes(title.id, epId),
  ])

  return (
    <div className="min-h-svh bg-background">
      <Navbar />
      <main className="pt-16">
        <div className="mx-auto max-w-7xl lg:flex lg:gap-6 lg:px-8 lg:py-6">
          <div className="lg:flex-1">
            <div className="lg:overflow-hidden lg:rounded-lg lg:border lg:border-border lg:bg-card">
              <VideoPlayer
                titleSlug={title.slug}
                episodeName={episode.name}
                episodeNumber={episode.episodeNumber}
                sources={sources.map((s) => ({
                  id: s.id,
                  quality: s.quality,
                  url: s.url,
                  downloadUrl: s.downloadUrl,
                }))}
                prev={adjacent.prev ? { id: adjacent.prev.id, episodeNumber: adjacent.prev.episodeNumber, name: adjacent.prev.name } : null}
                next={adjacent.next ? { id: adjacent.next.id, episodeNumber: adjacent.next.episodeNumber, name: adjacent.next.name } : null}
              />
            </div>
          </div>

          {/* Episode list sidebar */}
          <aside className="border-t border-border px-4 py-6 lg:w-80 lg:shrink-0 lg:border-t-0 lg:px-0 lg:py-0">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-foreground">
                <Link href={`/title/${title.slug}`} className="hover:text-primary">
                  {title.title}
                </Link>
              </h2>
              <span className="text-xs text-muted-foreground">{adjacent.list.length} episodes</span>
            </div>
            <ul className="flex flex-col gap-2 lg:max-h-[70vh] lg:overflow-y-auto lg:pr-1 scrollbar-thin">
              {adjacent.list.map((ep) => {
                const active = ep.id === epId
                return (
                  <li key={ep.id}>
                    <Link
                      href={`/watch/${title.slug}/${ep.id}`}
                      className={cn(
                        "flex items-center gap-3 rounded-md border p-2 transition-colors",
                        active ? "border-primary bg-primary/10" : "border-border bg-card hover:border-primary",
                      )}
                    >
                      <div className="relative aspect-video w-24 shrink-0 overflow-hidden rounded bg-secondary">
                        {ep.thumbnailUrl && (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={ep.thumbnailUrl || "/placeholder.svg"} alt="" className="h-full w-full object-cover" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <span className={cn("text-xs font-semibold", active ? "text-primary" : "text-muted-foreground")}>
                          EP {ep.episodeNumber}
                        </span>
                        <p className="truncate text-xs font-medium text-foreground">
                          {ep.name || `Episode ${ep.episodeNumber}`}
                        </p>
                      </div>
                    </Link>
                  </li>
                )
              })}
            </ul>
          </aside>
        </div>
      </main>
    </div>
  )
}
