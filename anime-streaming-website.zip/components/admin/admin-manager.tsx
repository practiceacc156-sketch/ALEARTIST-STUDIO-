"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { Trash2, Plus, ChevronDown, Film, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import type { AdminTitle } from "@/lib/queries"
import {
  createTitle,
  deleteTitle,
  createEpisode,
  deleteEpisode,
  createSource,
  deleteSource,
} from "@/app/actions/admin"

const KIND_OPTIONS = [
  { value: "anime", label: "Anime" },
  { value: "movie", label: "Movie" },
  { value: "webseries", label: "Web Series" },
  { value: "kdrama", label: "K-Drama" },
]

export function AdminManager({ titles }: { titles: AdminTitle[] }) {
  const router = useRouter()
  const [pending, startTransition] = useTransition()
  const [expanded, setExpanded] = useState<number | null>(titles[0]?.id ?? null)

  const refresh = () => router.refresh()

  const handleCreateTitle = (formData: FormData) => {
    startTransition(async () => {
      const res = await createTitle(formData)
      if (res?.ok) {
        ;(document.getElementById("add-title-form") as HTMLFormElement | null)?.reset()
        refresh()
      }
    })
  }

  return (
    <div className="flex flex-col gap-8">
      {/* Add Title */}
      <Card className="p-5">
        <h2 className="mb-4 text-lg font-semibold text-foreground">Add New Title</h2>
        <form id="add-title-form" action={handleCreateTitle} className="grid gap-4 sm:grid-cols-2">
          <div className="flex flex-col gap-2">
            <Label htmlFor="title">Title *</Label>
            <Input id="title" name="title" required placeholder="e.g. Shadow Blade" />
          </div>
          <div className="flex flex-col gap-2">
            <Label htmlFor="kind">Section *</Label>
            <select
              id="kind"
              name="kind"
              className="h-9 rounded-md border border-input bg-secondary/60 px-3 text-sm text-foreground outline-none focus:border-primary"
              defaultValue="anime"
            >
              {KIND_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </select>
          </div>
          <div className="flex flex-col gap-2 sm:col-span-2">
            <Label htmlFor="description">Description</Label>
            <Textarea id="description" name="description" rows={2} placeholder="Short synopsis..." />
          </div>
          <div className="flex flex-col gap-2">
            <Label htmlFor="posterUrl">Poster URL</Label>
            <Input id="posterUrl" name="posterUrl" placeholder="/posters/... or https://..." />
          </div>
          <div className="flex flex-col gap-2">
            <Label htmlFor="bannerUrl">Banner URL</Label>
            <Input id="bannerUrl" name="bannerUrl" placeholder="Wide banner image URL" />
          </div>
          <div className="flex flex-col gap-2">
            <Label htmlFor="genres">Genres (comma separated)</Label>
            <Input id="genres" name="genres" placeholder="Action, Thriller" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-2">
              <Label htmlFor="releaseYear">Year</Label>
              <Input id="releaseYear" name="releaseYear" type="number" placeholder="2024" />
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="rating">Rating</Label>
              <Input id="rating" name="rating" placeholder="TV-MA" />
            </div>
          </div>
          <label className="flex items-center gap-2 text-sm text-foreground sm:col-span-2">
            <input type="checkbox" name="featured" className="size-4 accent-[var(--primary)]" />
            Feature on homepage hero
          </label>
          <div className="sm:col-span-2">
            <Button type="submit" disabled={pending} className="gap-2">
              {pending ? <Loader2 className="size-4 animate-spin" /> : <Plus className="size-4" />}
              Add Title
            </Button>
          </div>
        </form>
      </Card>

      {/* Title list */}
      <div className="flex flex-col gap-3">
        <h2 className="text-lg font-semibold text-foreground">All Titles ({titles.length})</h2>
        {titles.length === 0 && (
          <p className="text-sm text-muted-foreground">No titles yet. Add your first one above.</p>
        )}
        {titles.map((title) => (
          <Card key={title.id} className="overflow-hidden p-0">
            <div className="flex items-center gap-3 p-4">
              <div className="relative h-16 w-11 shrink-0 overflow-hidden rounded bg-secondary">
                {title.posterUrl && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={title.posterUrl || "/placeholder.svg"} alt="" className="h-full w-full object-cover" />
                )}
              </div>
              <button
                className="flex min-w-0 flex-1 items-center justify-between gap-2 text-left"
                onClick={() => setExpanded(expanded === title.id ? null : title.id)}
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="truncate font-medium text-foreground">{title.title}</span>
                    {title.featured && <Badge className="shrink-0">Featured</Badge>}
                  </div>
                  <div className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground">
                    <Badge variant="secondary" className="capitalize">{title.kind}</Badge>
                    <span>{title.episodes.length} episode(s)</span>
                  </div>
                </div>
                <ChevronDown className={cn("size-5 shrink-0 text-muted-foreground transition-transform", expanded === title.id && "rotate-180")} />
              </button>
              <Button
                variant="ghost"
                size="icon"
                className="shrink-0 text-destructive hover:text-destructive"
                onClick={() => {
                  if (confirm(`Delete "${title.title}" and all its episodes?`)) {
                    startTransition(async () => {
                      await deleteTitle(title.id)
                      refresh()
                    })
                  }
                }}
                aria-label="Delete title"
              >
                <Trash2 className="size-4" />
              </Button>
            </div>

            {expanded === title.id && (
              <div className="border-t border-border bg-secondary/30 p-4">
                <EpisodeManager title={title} onChange={refresh} />
              </div>
            )}
          </Card>
        ))}
      </div>
    </div>
  )
}

function EpisodeManager({ title, onChange }: { title: AdminTitle; onChange: () => void }) {
  const [pending, startTransition] = useTransition()

  const handleAddEpisode = (formData: FormData) => {
    formData.set("titleId", String(title.id))
    startTransition(async () => {
      const res = await createEpisode(formData)
      if (res?.ok) {
        ;(document.getElementById(`ep-form-${title.id}`) as HTMLFormElement | null)?.reset()
        onChange()
      }
    })
  }

  return (
    <div className="flex flex-col gap-4">
      {/* Episodes list */}
      <div className="flex flex-col gap-3">
        {title.episodes.map((ep) => (
          <div key={ep.id} className="rounded-lg border border-border bg-card p-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Film className="size-4 text-primary" />
                <span className="text-sm font-medium text-foreground">
                  EP {ep.episodeNumber}: {ep.name || "Untitled"}
                </span>
                {ep.duration && <span className="text-xs text-muted-foreground">{ep.duration}</span>}
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="text-destructive hover:text-destructive"
                onClick={() => {
                  if (confirm("Delete this episode?")) {
                    startTransition(async () => {
                      await deleteEpisode(ep.id)
                      onChange()
                    })
                  }
                }}
                aria-label="Delete episode"
              >
                <Trash2 className="size-4" />
              </Button>
            </div>

            {/* Sources */}
            <div className="mt-3 flex flex-col gap-2 pl-6">
              {ep.sources.map((s) => (
                <div key={s.id} className="flex items-center gap-2 text-xs">
                  <Badge variant="secondary">{s.quality}</Badge>
                  <span className="truncate text-muted-foreground">{s.url || "(no url)"}</span>
                  <button
                    className="ml-auto text-destructive hover:underline"
                    onClick={() =>
                      startTransition(async () => {
                        await deleteSource(s.id)
                        onChange()
                      })
                    }
                  >
                    remove
                  </button>
                </div>
              ))}

              <SourceForm episodeId={ep.id} onChange={onChange} />
            </div>
          </div>
        ))}
      </div>

      {/* Add episode form */}
      <form
        id={`ep-form-${title.id}`}
        action={handleAddEpisode}
        className="grid gap-3 rounded-lg border border-dashed border-border p-3 sm:grid-cols-2"
      >
        <p className="text-sm font-medium text-foreground sm:col-span-2">Add Episode</p>
        <div className="grid grid-cols-2 gap-2">
          <Input name="season" type="number" placeholder="Season" defaultValue={1} />
          <Input name="episodeNumber" type="number" placeholder="Ep #" defaultValue={title.episodes.length + 1} />
        </div>
        <Input name="duration" placeholder="Duration e.g. 24m" />
        <Input name="name" placeholder="Episode name" className="sm:col-span-2" />
        <Input name="thumbnailUrl" placeholder="Thumbnail URL" className="sm:col-span-2" />
        <Textarea name="description" rows={2} placeholder="Episode description" className="sm:col-span-2" />
        <div className="sm:col-span-2">
          <Button type="submit" size="sm" disabled={pending} className="gap-2">
            {pending ? <Loader2 className="size-4 animate-spin" /> : <Plus className="size-4" />}
            Add Episode
          </Button>
        </div>
      </form>
    </div>
  )
}

function SourceForm({ episodeId, onChange }: { episodeId: number; onChange: () => void }) {
  const [pending, startTransition] = useTransition()
  const formId = `src-form-${episodeId}`

  const handleAdd = (formData: FormData) => {
    formData.set("episodeId", String(episodeId))
    startTransition(async () => {
      const res = await createSource(formData)
      if (res?.ok) {
        ;(document.getElementById(formId) as HTMLFormElement | null)?.reset()
        onChange()
      }
    })
  }

  return (
    <form id={formId} action={handleAdd} className="mt-1 flex flex-wrap items-center gap-2">
      <select
        name="quality"
        defaultValue="720p"
        className="h-8 rounded-md border border-input bg-secondary/60 px-2 text-xs text-foreground outline-none focus:border-primary"
      >
        {["360p", "480p", "720p", "1080p", "4K"].map((q) => (
          <option key={q} value={q}>
            {q}
          </option>
        ))}
      </select>
      <Input name="url" placeholder="Stream URL (mp4)" className="h-8 flex-1 min-w-40 text-xs" />
      <Input name="downloadUrl" placeholder="Download URL (optional)" className="h-8 flex-1 min-w-40 text-xs" />
      <Button type="submit" size="sm" variant="secondary" disabled={pending} className="h-8 gap-1 text-xs">
        {pending ? <Loader2 className="size-3 animate-spin" /> : <Plus className="size-3" />}
        Add quality
      </Button>
    </form>
  )
}
