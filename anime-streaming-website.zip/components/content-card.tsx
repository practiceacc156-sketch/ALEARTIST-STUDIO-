import Link from "next/link"
import { Play, Star } from "lucide-react"
import type { Title } from "@/lib/queries"

export function ContentCard({ title }: { title: Title }) {
  return (
    <Link
      href={`/title/${title.slug}`}
      className="group relative block w-36 shrink-0 sm:w-44 md:w-48"
    >
      <div className="relative aspect-[2/3] overflow-hidden rounded-md bg-secondary">
        {title.posterUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={title.posterUrl || "/placeholder.svg"}
            alt={`${title.title} poster`}
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-muted-foreground text-sm">
            {title.title}
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
        <div className="absolute inset-0 flex items-center justify-center opacity-0 transition-opacity duration-300 group-hover:opacity-100">
          <span className="flex size-12 items-center justify-center rounded-full bg-primary/90 text-primary-foreground">
            <Play className="size-5 fill-current" />
          </span>
        </div>
        {title.rating && (
          <span className="absolute left-2 top-2 rounded bg-black/70 px-1.5 py-0.5 text-[10px] font-medium text-white">
            {title.rating}
          </span>
        )}
      </div>
      <div className="mt-2">
        <h3 className="truncate text-sm font-medium text-foreground">{title.title}</h3>
        <div className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground">
          {title.releaseYear && <span>{title.releaseYear}</span>}
          {title.genres && (
            <span className="truncate">{title.genres.split(",")[0]}</span>
          )}
        </div>
      </div>
    </Link>
  )
}
