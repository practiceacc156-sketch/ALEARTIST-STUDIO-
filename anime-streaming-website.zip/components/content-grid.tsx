import { ContentCard } from "./content-card"
import type { Title } from "@/lib/queries"

export function ContentGrid({ titles }: { titles: Title[] }) {
  if (titles.length === 0) {
    return (
      <p className="px-4 py-16 text-center text-muted-foreground md:px-8">
        No titles here yet. Check back soon.
      </p>
    )
  }
  return (
    <div className="grid grid-cols-2 justify-items-center gap-4 px-4 sm:grid-cols-3 md:grid-cols-4 md:px-8 lg:grid-cols-5 xl:grid-cols-6">
      {titles.map((title) => (
        <ContentCard key={title.id} title={title} />
      ))}
    </div>
  )
}
