import Link from "next/link"
import { ChevronRight } from "lucide-react"
import type { Title } from "@/lib/queries"
import { ContentCard } from "./content-card"

export function ContentRow({
  heading,
  titles,
  viewAllHref,
}: {
  heading: string
  titles: Title[]
  viewAllHref?: string
}) {
  if (titles.length === 0) return null
  return (
    <section className="py-4">
      <div className="mb-3 flex items-center justify-between px-4 md:px-8">
        <h2 className="text-lg font-semibold text-foreground md:text-xl">{heading}</h2>
        {viewAllHref && (
          <Link
            href={viewAllHref}
            className="flex items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-primary"
          >
            View all <ChevronRight className="size-4" />
          </Link>
        )}
      </div>
      <div className="flex gap-3 overflow-x-auto px-4 pb-2 md:gap-4 md:px-8 scrollbar-thin">
        {titles.map((title) => (
          <ContentCard key={title.id} title={title} />
        ))}
      </div>
    </section>
  )
}
