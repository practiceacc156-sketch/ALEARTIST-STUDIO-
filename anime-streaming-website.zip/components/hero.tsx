import Link from "next/link"
import { Play, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { Title } from "@/lib/queries"

export function Hero({ title }: { title: Title }) {
  const bg = title.bannerUrl || title.posterUrl
  return (
    <section className="relative h-[70vh] min-h-[460px] w-full">
      {bg ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={bg || "/placeholder.svg"} alt={`${title.title} banner`} className="absolute inset-0 h-full w-full object-cover" />
      ) : (
        <div className="absolute inset-0 bg-secondary" />
      )}
      <div className="absolute inset-0 bg-gradient-to-r from-background via-background/70 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />

      <div className="relative z-10 mx-auto flex h-full max-w-7xl flex-col justify-end px-4 pb-16 md:px-8 md:pb-20">
        <span className="mb-3 inline-flex w-fit items-center rounded bg-primary px-2 py-1 text-xs font-semibold uppercase tracking-wide text-primary-foreground">
          ALEARTIST Original
        </span>
        <h1 className="max-w-2xl font-heading text-4xl leading-none tracking-wide text-foreground md:text-6xl text-balance">
          {title.title}
        </h1>
        <div className="mt-3 flex flex-wrap items-center gap-3 text-sm text-foreground/80">
          {title.releaseYear && <span>{title.releaseYear}</span>}
          {title.rating && (
            <span className="rounded border border-border px-1.5 py-0.5 text-xs">{title.rating}</span>
          )}
          {title.genres && <span>{title.genres.split(",").join(" • ")}</span>}
        </div>
        <p className="mt-4 max-w-xl text-sm leading-relaxed text-foreground/80 md:text-base line-clamp-3">
          {title.description}
        </p>
        <div className="mt-6 flex flex-wrap items-center gap-3">
          <Button asChild size="lg" className="gap-2">
            <Link href={`/title/${title.slug}`}>
              <Play className="size-5 fill-current" /> Play
            </Link>
          </Button>
          <Button asChild size="lg" variant="secondary" className="gap-2">
            <Link href={`/title/${title.slug}`}>
              <Info className="size-5" /> More Info
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
