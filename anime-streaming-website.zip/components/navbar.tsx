import { auth } from "@/lib/auth"
import { headers } from "next/headers"
import { NavbarClient } from "./navbar-client"

export async function Navbar() {
  const session = await auth.api.getSession({ headers: await headers() })
  return <NavbarClient userName={session?.user?.name ?? null} />
}
