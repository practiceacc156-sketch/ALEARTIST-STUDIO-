import Link from "next/link"

export function SiteFooter() {
  return (
    <footer className="mt-12 border-t border-border bg-background/60 px-4 py-10 md:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="flex flex-col gap-6 md:flex-row md:items-start md:justify-between">
          <div>
            <span className="font-heading text-xl tracking-wide text-primary">ALEARTIST STUDIO INDIA</span>
            <p className="mt-2 max-w-sm text-sm text-muted-foreground">
              Fan-dubbed anime, movies, web series, and K-dramas. Watch and download free, in HD.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-8 sm:grid-cols-4">
            <FooterCol heading="Browse" links={[
              { href: "/browse/anime", label: "Anime" },
              { href: "/browse/movie", label: "Movies" },
              { href: "/browse/webseries", label: "Web Series" },
              { href: "/browse/kdrama", label: "K-Dramas" },
            ]} />
            <FooterCol heading="Account" links={[
              { href: "/sign-in", label: "Sign in" },
              { href: "/sign-up", label: "Sign up" },
              { href: "/watchlist", label: "My List" },
            ]} />
            <FooterCol heading="Studio" links={[
              { href: "/admin", label: "Admin Panel" },
            ]} />
          </div>
        </div>
        <p className="mt-8 text-xs text-muted-foreground">
          {"© "}
          {new Date().getFullYear()} ALEARTIST STUDIO INDIA. Fan-dubbed content for the community. All trademarks belong to their respective owners.
        </p>
      </div>
    </footer>
  )
}

function FooterCol({ heading, links }: { heading: string; links: { href: string; label: string }[] }) {
  return (
    <div>
      <h3 className="mb-3 text-sm font-semibold text-foreground">{heading}</h3>
      <ul className="flex flex-col gap-2">
        {links.map((l) => (
          <li key={l.href + l.label}>
            <Link href={l.href} className="text-sm text-muted-foreground transition-colors hover:text-primary">
              {l.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  )
}
