"use client"

import { useMemo, useRef, useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { ChevronLeft, ChevronRight, Download, ListVideo } from "lucide-react"
import { Button } from "@/components/ui/button"

type Source = { id: number; quality: string; url: string; downloadUrl: string }
type EpisodeLite = { id: number; episodeNumber: number; name: string }

function qualityRank(q: string) {
  const n = Number.parseInt(q, 10)
  return Number.isNaN(n) ? 0 : n
}

export function VideoPlayer({
  titleSlug,
  episodeName,
  episodeNumber,
  sources,
  prev,
  next,
}: {
  titleSlug: string
  episodeName: string
  episodeNumber: number
  sources: Source[]
  prev: EpisodeLite | null
  next: EpisodeLite | null
}) {
  const router = useRouter()
  const videoRef = useRef<HTMLVideoElement>(null)

  const sortedSources = useMemo(
    () => [...sources].sort((a, b) => qualityRank(b.quality) - qualityRank(a.quality)),
    [sources],
  )
  const [activeId, setActiveId] = useState(sortedSources[0]?.id ?? null)
  const activeSource = sortedSources.find((s) => s.id === activeId) ?? sortedSources[0] ?? null

  const switchQuality = (id: number) => {
    const video = videoRef.current
    const time = video?.currentTime ?? 0
    const wasPlaying = video ? !video.paused : false
    setActiveId(id)
    requestAnimationFrame(() => {
      if (videoRef.current) {
        videoRef.current.currentTime = time
        if (wasPlaying) void videoRef.current.play()
      }
    })
  }

  return (
    <div className="w-full">
      <div className="relative aspect-video w-full overflow-hidden bg-black">
        {activeSource ? (
          <video
            ref={videoRef}
            key={activeSource.id}
            src={activeSource.url}
            controls
            autoPlay
            playsInline
            className="h-full w-full"
            onEnded={() => {
              if (next) router.push(`/watch/${titleSlug}/${next.id}`)
            }}
          >
            <track kind="captions" />
          </video>
        ) : (
          <div className="flex h-full w-full items-center justify-center text-muted-foreground">
            No video source available for this episode.
          </div>
        )}
      </div>

      <div className="mx-auto max-w-5xl px-4 py-5 md:px-0">
        <div className="flex flex-col gap-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <span className="text-sm font-semibold text-primary">Episode {episodeNumber}</span>
              <h1 className="text-lg font-semibold text-foreground md:text-xl">
                {episodeName || `Episode ${episodeNumber}`}
              </h1>
            </div>
            <Button asChild variant="ghost" size="sm" className="gap-2">
              <Link href={`/title/${titleSlug}`}>
                <ListVideo className="size-4" /> All episodes
              </Link>
            </Button>
          </div>

          {/* Quality options */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-medium text-muted-foreground">Quality:</span>
            {sortedSources.map((s) => (
              <button
                key={s.id}
                onClick={() => switchQuality(s.id)}
                className={
                  "rounded-md border px-3 py-1 text-xs font-medium transition-colors " +
                  (s.id === activeId
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border bg-secondary text-foreground hover:border-primary")
                }
              >
                {s.quality}
              </button>
            ))}
            {activeSource && (activeSource.downloadUrl || activeSource.url) && (
              <a
                href={activeSource.downloadUrl || activeSource.url}
                download
                className="ml-auto inline-flex items-center gap-1.5 rounded-md border border-border bg-secondary px-3 py-1 text-xs font-medium text-foreground transition-colors hover:border-primary"
              >
                <Download className="size-3.5" /> Download {activeSource.quality}
              </a>
            )}
          </div>

          {/* Prev / Next navigation */}
          <div className="flex items-center justify-between gap-3 border-t border-border pt-4">
            {prev ? (
              <Button asChild variant="secondary" className="gap-2">
                <Link href={`/watch/${titleSlug}/${prev.id}`}>
                  <ChevronLeft className="size-4" />
                  <span className="hidden sm:inline">Previous: EP {prev.episodeNumber}</span>
                  <span className="sm:hidden">Prev</span>
                </Link>
              </Button>
            ) : (
              <Button variant="secondary" className="gap-2" disabled>
                <ChevronLeft className="size-4" /> Prev
              </Button>
            )}

            {next ? (
              <Button asChild className="gap-2">
                <Link href={`/watch/${titleSlug}/${next.id}`}>
                  <span className="hidden sm:inline">Next: EP {next.episodeNumber}</span>
                  <span className="sm:hidden">Next</span>
                  <ChevronRight className="size-4" />
                </Link>
              </Button>
            ) : (
              <Button className="gap-2" disabled>
                Next <ChevronRight className="size-4" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
