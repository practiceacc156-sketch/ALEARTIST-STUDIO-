"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { Check, Plus, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { toggleWatchlist } from "@/app/actions/watchlist"

export function WatchlistButton({
  titleId,
  initialInList,
  isAuthed,
}: {
  titleId: number
  initialInList: boolean
  isAuthed: boolean
}) {
  const router = useRouter()
  const [inList, setInList] = useState(initialInList)
  const [pending, startTransition] = useTransition()

  const handleClick = () => {
    if (!isAuthed) {
      router.push("/sign-in")
      return
    }
    startTransition(async () => {
      const res = await toggleWatchlist(titleId)
      if (res.ok) setInList(res.added)
    })
  }

  return (
    <Button variant="secondary" size="lg" className="gap-2" onClick={handleClick} disabled={pending}>
      {pending ? (
        <Loader2 className="size-5 animate-spin" />
      ) : inList ? (
        <Check className="size-5" />
      ) : (
        <Plus className="size-5" />
      )}
      {inList ? "In My List" : "My List"}
    </Button>
  )
}
