import { pgTable, text, timestamp, boolean, serial, integer } from "drizzle-orm/pg-core"

// --- Better Auth required tables -------------------------------------------
// Column names are camelCase to match Better Auth's defaults. Do not rename.

export const user = pgTable("user", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  emailVerified: boolean("emailVerified").notNull().default(false),
  image: text("image"),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
})

export const session = pgTable("session", {
  id: text("id").primaryKey(),
  expiresAt: timestamp("expiresAt").notNull(),
  token: text("token").notNull().unique(),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
  ipAddress: text("ipAddress"),
  userAgent: text("userAgent"),
  userId: text("userId")
    .notNull()
    .references(() => user.id, { onDelete: "cascade" }),
})

export const account = pgTable("account", {
  id: text("id").primaryKey(),
  accountId: text("accountId").notNull(),
  providerId: text("providerId").notNull(),
  userId: text("userId")
    .notNull()
    .references(() => user.id, { onDelete: "cascade" }),
  accessToken: text("accessToken"),
  refreshToken: text("refreshToken"),
  idToken: text("idToken"),
  accessTokenExpiresAt: timestamp("accessTokenExpiresAt"),
  refreshTokenExpiresAt: timestamp("refreshTokenExpiresAt"),
  scope: text("scope"),
  password: text("password"),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
})

export const verification = pgTable("verification", {
  id: text("id").primaryKey(),
  identifier: text("identifier").notNull(),
  value: text("value").notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow(),
  updatedAt: timestamp("updatedAt").defaultNow(),
})

// --- App tables ------------------------------------------------------------

// kind: 'anime' | 'movie' | 'webseries' | 'kdrama'
export const titles = pgTable("titles", {
  id: serial("id").primaryKey(),
  kind: text("kind").notNull().default("anime"),
  title: text("title").notNull(),
  slug: text("slug").notNull(),
  description: text("description").notNull().default(""),
  posterUrl: text("poster_url").notNull().default(""),
  bannerUrl: text("banner_url").notNull().default(""),
  genres: text("genres").notNull().default(""),
  releaseYear: integer("release_year"),
  rating: text("rating").notNull().default(""),
  featured: boolean("featured").notNull().default(false),
  trailerUrl: text("trailer_url").notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
})

export const episodes = pgTable("episodes", {
  id: serial("id").primaryKey(),
  titleId: integer("title_id").notNull(),
  season: integer("season").notNull().default(1),
  episodeNumber: integer("episode_number").notNull().default(1),
  name: text("name").notNull().default(""),
  description: text("description").notNull().default(""),
  thumbnailUrl: text("thumbnail_url").notNull().default(""),
  duration: text("duration").notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
})

export const episodeSources = pgTable("episode_sources", {
  id: serial("id").primaryKey(),
  episodeId: integer("episode_id").notNull(),
  quality: text("quality").notNull().default("720p"),
  url: text("url").notNull().default(""),
  downloadUrl: text("download_url").notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
})

export const watchlist = pgTable("watchlist", {
  id: serial("id").primaryKey(),
  userId: text("userId").notNull(),
  titleId: integer("title_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
})
