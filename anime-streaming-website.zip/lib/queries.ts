import { db } from "@/lib/db"
import { titles, episodes, episodeSources } from "@/lib/db/schema"
import { and, asc, desc, eq } from "drizzle-orm"

export type Title = typeof titles.$inferSelect
export type Episode = typeof episodes.$inferSelect
export type EpisodeSource = typeof episodeSources.$inferSelect

export const KINDS = ["anime", "movie", "webseries", "kdrama"] as const
export type Kind = (typeof KINDS)[number]

export const KIND_LABELS: Record<Kind, string> = {
  anime: "Anime",
  movie: "Movies",
  webseries: "Web Series",
  kdrama: "K-Dramas",
}

export async function getAllTitles() {
  return db.select().from(titles).orderBy(desc(titles.createdAt))
}

export async function getTitlesByKind(kind: Kind) {
  return db.select().from(titles).where(eq(titles.kind, kind)).orderBy(desc(titles.createdAt))
}

export async function getFeaturedTitle() {
  const rows = await db.select().from(titles).where(eq(titles.featured, true)).limit(1)
  if (rows.length > 0) return rows[0]
  const fallback = await db.select().from(titles).orderBy(desc(titles.createdAt)).limit(1)
  return fallback[0] ?? null
}

export async function getTitleBySlug(slug: string) {
  const rows = await db.select().from(titles).where(eq(titles.slug, slug)).limit(1)
  return rows[0] ?? null
}

export async function getTitleById(id: number) {
  const rows = await db.select().from(titles).where(eq(titles.id, id)).limit(1)
  return rows[0] ?? null
}

export async function getEpisodesForTitle(titleId: number) {
  return db
    .select()
    .from(episodes)
    .where(eq(episodes.titleId, titleId))
    .orderBy(asc(episodes.season), asc(episodes.episodeNumber))
}

export async function getEpisodeById(id: number) {
  const rows = await db.select().from(episodes).where(eq(episodes.id, id)).limit(1)
  return rows[0] ?? null
}

export async function getSourcesForEpisode(episodeId: number) {
  return db.select().from(episodeSources).where(eq(episodeSources.episodeId, episodeId)).orderBy(asc(episodeSources.id))
}

export async function getAdjacentEpisodes(titleId: number, currentEpisodeId: number) {
  const list = await getEpisodesForTitle(titleId)
  const index = list.findIndex((e) => e.id === currentEpisodeId)
  return {
    list,
    current: index >= 0 ? list[index] : null,
    prev: index > 0 ? list[index - 1] : null,
    next: index >= 0 && index < list.length - 1 ? list[index + 1] : null,
  }
}

export async function searchTitles(query: string) {
  const all = await getAllTitles()
  const q = query.toLowerCase().trim()
  if (!q) return []
  return all.filter((t) => t.title.toLowerCase().includes(q) || t.genres.toLowerCase().includes(q))
}

export type AdminTitle = Title & {
  episodes: (Episode & { sources: EpisodeSource[] })[]
}

export async function getAdminData(): Promise<AdminTitle[]> {
  const [allTitles, allEpisodes, allSources] = await Promise.all([
    db.select().from(titles).orderBy(desc(titles.createdAt)),
    db.select().from(episodes).orderBy(asc(episodes.season), asc(episodes.episodeNumber)),
    db.select().from(episodeSources).orderBy(asc(episodeSources.id)),
  ])

  return allTitles.map((t) => ({
    ...t,
    episodes: allEpisodes
      .filter((e) => e.titleId === t.id)
      .map((e) => ({
        ...e,
        sources: allSources.filter((s) => s.episodeId === e.id),
      })),
  }))
}
